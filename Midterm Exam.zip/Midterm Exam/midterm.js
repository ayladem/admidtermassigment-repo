
 //11
 const number = (Number(prompt("Please enter a number")));
 if(number!=number.valueOf(Number)){
    prompt("Please enter a new number")
 }
    else if(number==null){
        prompt("Please enter a new number")
}
else if(number==3||number===8){
console.log("Congrats! You win the game!")
     }
     else if(number==101||number==108){
        console.log("Congrats! You win the game!")  
     }else{
         console.log("sorry game is over")
     }
   //13

  function calculatetotalbal(Pamount,Interestrate,timeperiod){
      
      const interest=(Pamount*Interestrate*timeperiod)
    return Pamount+interest;
  }
  console.log(calculatetotalbal(10000,0.01,10))

  const stateUS=[];
  stateUS.push('Alabama','102','New Jersey','Arizona','New York','Arkansas','California', 'Colorado', 'Washington' )
  console.log(stateUS)
  console.log(stateUS[0],stateUS[1],stateUS[2],stateUS[3])
  
  stateUS.splice(2,1)
  console.log(stateUS)
  stateUS.splice(4,1)

  console.log(stateUS)
  stateUS.splice(1,1,"Alaska")
  
  console.log(stateUS)
  console.log(stateUS.length)

  if(typeof stateUS[1]==='string'){
      console.log("string")
  }else if(stateUS[1]===Number){
      console.log("number")
  }
  if(typeof stateUS[2]==='string'){
    console.log("string")
}else if(stateUS[2]===Number){
    console.log("number")
}
if(typeof stateUS[3]==='string'){
    console.log("string")
}else if(stateUS[3]===Number){
    console.log("number")
}
if(typeof stateUS[4]==='string'){
    console.log("string")
}else if(stateUS[4]===Number){
    console.log("number")
}
if(typeof stateUS[5]==='string'){
    console.log("string")
}else if(stateUS[5]===Number){
    console.log("number")
}
if(typeof stateUS[6]==='string'){
    console.log("string")
}else if(stateUS[6]===Number){
    console.log("number")
}
if(typeof stateUS[7]==='string'){
    console.log("string")
}else if(stateUS[7]===Number){
    console.log("number")
}
if(typeof stateUS[8]==='string'){
    console.log("string")
}else if(stateUS[8]===Number){
    console.log("number")
}
if(typeof stateUS[9]==='string'){
    console.log("string")
}else if(stateUS[9]===Number){
    console.log("number")
}

const Markobject={
    firstName:"gfgf",
    lastName
}